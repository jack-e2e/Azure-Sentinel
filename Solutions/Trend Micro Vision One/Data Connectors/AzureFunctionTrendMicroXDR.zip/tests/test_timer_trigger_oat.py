import unittest
import importlib

from unittest.mock import ANY, patch, MagicMock
from datetime import datetime, timedelta

from requests.models import HTTPError

from shared_code.models.oat import OATDetectionResult


MOCK_TOKEN = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJjaWQiOiI4Yzg0MDg3My0zMTQ1LTRlNWEtYWVkZS0wMjE2NzljZTIzZDgiLCJjcGlkIjoic3ZwIiwicHBpZCI6ImN1cyIsIml0IjoxNjE1ODgwNzg1LCJ1aWQiOiJteGRyXzRiOTE0ZTYyQG1kci50cmVuZG1pY3JvLmNvbSIsInBsIjoiIiwiZXQiOjE2NDc0MTY3ODV9.V2SZHU85H8K55DpzHemToIr55kWaOQMWVV5CdImKGSePpntapsqW1tIEKbpuAemMyicKUNM1ewwC8fwJNZl7bW8puugYg92ynkXWGqKQiureKwCZM7Kfp-L-4LUvTsLF_DVDCECsptJNKkFZANryKqOFdEmiowmwRaqkoHkDT5qF_xCRnGx5nfzof8Nb_ey6PMQuH2mdOJRtfHkW4m9HZ3C-Ab2kuizD3J-BkOWGmn642hv1C9ClNp5IesMF_bhT21rIO4jkSW6GPz5nb9cEFMuepJK7F8177BGNh8LfJzfmeGgX141QGje4LdSXGq0eUlXzFxg0hMAXCS35a6bQeKGTh5Dfnxt4iSGLq47_ddiSEBifWuMiLyjAbxxV9QiF-Bee9q_gZdsczJCO9c7I4eoW2acqTOva-Ts0VVenXrp0g5qdBtZgoFOG4BZj_dnzla3fUa60rFlsE6_4VbSv0-mV7yZirRrB7cxwb2Gqzw_7dFCdKEg3Eax5ljT882FtJeUFGH1cOyUf-Uj4YlfByDSQyvPtqlyNoHX66Jz6yauWuJbL9n1cN_ZseKdf3gQtRRenNTLZG84dATj-WKYcp3w-KJtpCEDxLFbZFwb5Te7NlxrItHk0wPaG0opxbwDUwZTJ7yUhYORgD8U4fW0rpiC3Si5a8BV06IPf8vVZst4'
ENV = {
    "apiTokens": MOCK_TOKEN,
    "regionCode": "us",
    "AzureWebJobsStorage": "fakeconnection",
    "workspaceId": "6a183caf-a148-4a43-845a-db6f4e645bfb",
    "workspaceKey": "m4qj7Y+sgW1hTi66m07/++fkGl38Dq46DwmDwOdx/vaWU86N5x8NicNmBeXXmgSbosTIfpL+AEuLigwQhidVPw==",
    "defaultOatQueryMinutes": '5',
    "maxOatQueryMinutes": '60',
}
MOCK_CLP_ID = '8c840873-3145-4e5a-aede-021679ce23d8'
MOCK_TIME_BUFFER = 15


class TestTimerTriggerOAT(unittest.TestCase):
    def setUp(self):
        patcher = patch.dict('os.environ', ENV)
        patcher.start()
        self.addCleanup(patcher.stop)
        self.timer_trigger_oat = importlib.reload(
            importlib.import_module('timer_trigger_oat')
        )
        super().setUp()

    @patch('timer_trigger_oat.update_last_success_time')
    @patch('timer_trigger_oat.generate_time')
    @patch('timer_trigger_oat.get_oat_list')
    @patch('timer_trigger_oat.TableService')
    def test_timer_trigger_oat_success(
        self, table_service, get_oat_list, generate_time, update_last_success_time
    ):
        req = MagicMock()
        msg = MagicMock()

        mock_oat_record = {'uuid': 'test_01'}
        mock_oat_record2 = {'uuid': 'test_02'}
        post_data = [{'query': 'test_01 and test_02'}]
        result = OATDetectionResult(
            total_count=10,
            detections=[mock_oat_record, mock_oat_record2],
            search_api_post_data=post_data,
        )
        get_oat_list.return_value = result
        mock_start_time = datetime(2021, 4, 1, 12, 0, 0)
        mock_end_time = datetime(2021, 4, 1, 12, 5, 0)
        generate_time.return_value = mock_start_time, mock_end_time

        self.timer_trigger_oat.main(req, msg)

        get_oat_list.assert_called_with(MOCK_TOKEN, ANY, ANY)
        msg.set.assert_called_with(
            self.timer_trigger_oat.build_queue_message(MOCK_CLP_ID, result)
        )
        update_last_success_time.assert_called_with(
            table_service(), MOCK_CLP_ID, mock_end_time
        )

    @patch('timer_trigger_oat.update_last_success_time')
    @patch('timer_trigger_oat.generate_time')
    @patch('timer_trigger_oat.get_oat_list')
    @patch('timer_trigger_oat.TableService')
    def test_timer_trigger_oat_when_have_more_pages_then_get_all_pages(
        self, table_service, get_oat_list, generate_time, update_last_success_time
    ):
        req = MagicMock()
        msg = MagicMock()

        mock_oat_record = {'OatId': 1}
        result_with_next_page = OATDetectionResult(
            total_count=10,
            detections=[mock_oat_record, mock_oat_record],
            search_api_post_data=[],
            next_batch_token='Next',
        )
        result_no_next_page = OATDetectionResult(
            total_count=10,
            detections=[mock_oat_record, mock_oat_record],
            search_api_post_data=[],
        )
        get_oat_list.side_effect = [
            result_with_next_page,
            result_no_next_page,
        ]

        mock_start_time = datetime(2021, 4, 1, 12, 0, 0)
        mock_end_time = datetime(2021, 4, 1, 12, 5, 0)
        generate_time.return_value = mock_start_time, mock_end_time

        self.timer_trigger_oat.main(req, msg)

        self.assertEqual(get_oat_list.call_count, 2)
        result = []
        result.extend(
            self.timer_trigger_oat.build_queue_message(
                MOCK_CLP_ID, result_with_next_page
            )
        )
        result.extend(
            self.timer_trigger_oat.build_queue_message(MOCK_CLP_ID, result_no_next_page)
        )
        msg.set.assert_called_with(result)
        update_last_success_time.assert_called_with(
            table_service(), MOCK_CLP_ID, mock_end_time
        )

    @patch('timer_trigger_oat.LogAnalytics')
    @patch('timer_trigger_oat.update_last_success_time')
    @patch('timer_trigger_oat.generate_time')
    @patch('timer_trigger_oat.get_oat_list')
    @patch('timer_trigger_oat.TableService')
    def test_timer_trigger_oat_error(
        self,
        table_service,
        get_oat_list,
        generate_time,
        update_last_success_time,
        log_ananlytics,
    ):
        req = MagicMock()
        msg = MagicMock()

        get_oat_list.side_effect = HTTPError()
        mock_start_time = datetime(2021, 4, 1, 12, 0, 0)
        mock_end_time = datetime(2021, 4, 1, 12, 5, 0)
        generate_time.return_value = mock_start_time, mock_end_time

        with self.assertRaises(HTTPError):
            self.timer_trigger_oat.main(req, msg)

        get_oat_list.assert_called_with(MOCK_TOKEN, ANY, ANY)
        msg.set.assert_not_called()
        update_last_success_time.assert_not_called()
        log_ananlytics().post_data.assert_called_with(
            {
                "clpId": MOCK_CLP_ID,
                "queryStartTime": ANY,
                "queryEndTime": ANY,
                "error": str(HTTPError()),
            }
        )

    @patch('timer_trigger_oat.datetime')
    @patch('timer_trigger_oat.get_last_success_time')
    def test_generate_time_with_default_time(
        self, get_last_success_time, mock_datetime
    ):
        mock_start_time = datetime(2021, 4, 21, 8, 50)
        mock_end_time = datetime(2021, 4, 21, 8, 55)
        get_last_success_time.return_value = None
        mock_datetime.utcnow.return_value = mock_end_time

        result = self.timer_trigger_oat.generate_time(None, MOCK_CLP_ID)

        self.assertTupleEqual(
            result,
            (
                mock_start_time - timedelta(minutes=MOCK_TIME_BUFFER),
                mock_end_time - timedelta(minutes=MOCK_TIME_BUFFER),
            ),
        )

    @patch('timer_trigger_oat.datetime')
    @patch('timer_trigger_oat.get_last_success_time')
    def test_generate_time_with_last_success_time(
        self, get_last_success_time, mock_datetime
    ):
        mock_start_time = datetime(2021, 4, 21, 8, 55)
        mock_end_time = datetime(2021, 4, 21, 8, 55)
        get_last_success_time.return_value = mock_start_time
        mock_datetime.utcnow.return_value = mock_end_time

        result = self.timer_trigger_oat.generate_time(None, MOCK_CLP_ID)

        self.assertTupleEqual(
            result,
            (mock_start_time, mock_end_time - timedelta(minutes=MOCK_TIME_BUFFER)),
        )

    @patch('timer_trigger_oat.datetime')
    @patch('timer_trigger_oat.get_last_success_time')
    def test_generate_time_with_last_success_time_over_max_time_range(
        self, get_last_success_time, mock_datetime
    ):
        mock_start_time = datetime(2021, 4, 20, 8, 55)
        mock_end_time = datetime(2021, 4, 21, 8, 55)
        get_last_success_time.return_value = mock_start_time
        mock_datetime.utcnow.return_value = mock_end_time

        result = self.timer_trigger_oat.generate_time(None, MOCK_CLP_ID)

        self.assertTupleEqual(
            result, (mock_start_time, mock_start_time + timedelta(minutes=60))
        )
