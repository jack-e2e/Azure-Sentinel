import unittest
import importlib
from unittest.mock import ANY, patch

MOCK_TOKEN = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJjaWQiOiI4Yzg0MDg3My0zMTQ1LTRlNWEtYWVkZS0wMjE2NzljZTIzZDgiLCJjcGlkIjoic3ZwIiwicHBpZCI6ImN1cyIsIml0IjoxNjE1ODgwNzg1LCJ1aWQiOiJteGRyXzRiOTE0ZTYyQG1kci50cmVuZG1pY3JvLmNvbSIsInBsIjoiIiwiZXQiOjE2NDc0MTY3ODV9.V2SZHU85H8K55DpzHemToIr55kWaOQMWVV5CdImKGSePpntapsqW1tIEKbpuAemMyicKUNM1ewwC8fwJNZl7bW8puugYg92ynkXWGqKQiureKwCZM7Kfp-L-4LUvTsLF_DVDCECsptJNKkFZANryKqOFdEmiowmwRaqkoHkDT5qF_xCRnGx5nfzof8Nb_ey6PMQuH2mdOJRtfHkW4m9HZ3C-Ab2kuizD3J-BkOWGmn642hv1C9ClNp5IesMF_bhT21rIO4jkSW6GPz5nb9cEFMuepJK7F8177BGNh8LfJzfmeGgX141QGje4LdSXGq0eUlXzFxg0hMAXCS35a6bQeKGTh5Dfnxt4iSGLq47_ddiSEBifWuMiLyjAbxxV9QiF-Bee9q_gZdsczJCO9c7I4eoW2acqTOva-Ts0VVenXrp0g5qdBtZgoFOG4BZj_dnzla3fUa60rFlsE6_4VbSv0-mV7yZirRrB7cxwb2Gqzw_7dFCdKEg3Eax5ljT882FtJeUFGH1cOyUf-Uj4YlfByDSQyvPtqlyNoHX66Jz6yauWuJbL9n1cN_ZseKdf3gQtRRenNTLZG84dATj-WKYcp3w-KJtpCEDxLFbZFwb5Te7NlxrItHk0wPaG0opxbwDUwZTJ7yUhYORgD8U4fW0rpiC3Si5a8BV06IPf8vVZst4'
MOCK_XDR_HOST_URL = 'https://test.host.com'
MOCK_TRACE_ID = '645f4f62-e3e4-45a6-a853-af64cfd8d3e5'
MOCK_TASK_ID = '35fd435a-5baa-4de5-b5bd-9893b5aaa3cb'

ENV = {"apiTokens": MOCK_TOKEN, "xdrHostUrl": MOCK_XDR_HOST_URL}
HTTP_HEADER = {
    'Authorization': f"Bearer {MOCK_TOKEN}",
    'Content-Type': 'application/json;charset=utf-8',
    'x-trace-id': MOCK_TRACE_ID,
    'x-task-id': MOCK_TASK_ID,
    'User-Agent': 'TMXDRSentinelAddon/1.0.0'
}


class TestWorkbenchService(unittest.TestCase):
    def setUp(self):
        patcher = patch.dict('os.environ', ENV)
        patcher.start()
        patch('shared_code.trace_utils.trace.trace_manager.trace_id', MOCK_TRACE_ID).start()
        patch('shared_code.trace_utils.trace.trace_manager.task_id', MOCK_TASK_ID).start()
        self.addCleanup(patcher.stop)
        self.workbench_service = importlib.reload(
            importlib.import_module('shared_code.services.workbench_service')
        )
        super().setUp()

    @patch('shared_code.services.workbench_service.requests')
    def test_get_workbench_list_success(self, requests):
        query_params = {
            'source': 'all',
            'investigationStatus': 'null',
            'sortBy': 'createdTime',
            'queryTimeField': 'createdTime',
            'offset': 0,
            'limit': 100,
            'startDateTime': '2021-04-21T08:00:00',
            'endDateTime': '2021-04-21T08:00:05',
        }

        url = f"{MOCK_XDR_HOST_URL}/v2.0/siem/events"
        requests.get.return_value.json.return_value = {
            'data': {'totalCount': 1, 'workbenchRecords': ['test']}
        }

        result = self.workbench_service.get_workbench_list(
            MOCK_TOKEN, '2021-04-21T08:00:00', '2021-04-21T08:00:05', 0, 100
        )

        requests.get.assert_called_with(url, headers=HTTP_HEADER, params=query_params)
        self.assertTupleEqual(result, (1, ['test']))

    @patch('shared_code.services.workbench_service.requests')
    def test_get_workbench_detail_success(self, requests):
        mock_workbench_id = 1
        url = f"{MOCK_XDR_HOST_URL}/v2.0/xdr/workbench/workbenches/{mock_workbench_id}"
        requests.get.return_value.json.return_value = {
            'data': {'workbenchName': 'test'}
        }

        result = self.workbench_service.get_workbench_detail(
            MOCK_TOKEN, mock_workbench_id
        )

        requests.get.assert_called_with(url, headers=HTTP_HEADER)
        self.assertEqual(result, {'workbenchName': 'test'})

    @patch('shared_code.services.workbench_service.requests')
    def test_get_rca_task_success(self, requests):
        mock_workbench_id = 1
        url = f"{MOCK_XDR_HOST_URL}/v3.0/xdr/mssp/workbench/workbenches/{mock_workbench_id}/tasks/rca"
        requests.get.return_value.json.return_value = {
            'data': {'workbenchName': 'test'}
        }

        result = self.workbench_service.get_rca_task(MOCK_TOKEN, mock_workbench_id)

        requests.get.assert_called_with(url, headers=HTTP_HEADER)
        self.assertEqual(result, {'workbenchName': 'test'})

    @patch('shared_code.services.workbench_service.requests')
    def test_get_rca_task_detail_success(self, requests):
        mock_task_id = '1'
        mock_endpoint_id = '1111-1111-1111-11111'
        url = f"{MOCK_XDR_HOST_URL}/v3.0/xdr/mssp/workbench/tasks/rca/{mock_task_id}/results/{mock_endpoint_id}"
        requests.get.return_value.json.return_value = {
            'data': {'workbenchName': 'test'}
        }

        result = self.workbench_service.get_rca_task_detail(
            MOCK_TOKEN, mock_task_id, mock_endpoint_id
        )

        requests.get.assert_called_with(url, headers=HTTP_HEADER)
        self.assertEqual(result, {'workbenchName': 'test'})
